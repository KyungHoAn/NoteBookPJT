package com.example.NoteBook.config;

import org.springframework.security.core.session.SessionRegistryImpl;

public class SpringSecuritySessionRegistImpl extends SessionRegistryImpl {
}
