package com.example.notebook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoteBookApplicationTests {

    @Test
    void contextLoads() {
    }

}
